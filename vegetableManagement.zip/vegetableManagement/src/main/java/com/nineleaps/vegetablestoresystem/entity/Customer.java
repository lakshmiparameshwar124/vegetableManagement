package com.nineleaps.vegetablestoresystem.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Size;
@Entity
@Table(name= "customer")
public class Customer {
	@Id
	@Column(name= "customer_id",nullable = false)
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private Long customerId;
	
	@Column(name ="customer_name",nullable = false)
	private String customerName;
	  
	@Email
	@Column(name="customer_email",nullable = false)
	private String customerEmail ;
	 
	@Size(min=10,max=10,message="phone number must be of 10 digit")
	 @Column(name = "customer_phone_number",nullable = false)
	private String customerPhoneNumber;
	
	 
	  @Column(name = "customer_house_number",nullable = false)
	  private String customerHouseNumber;
	  @Column(name = "customer_street",nullable = false)
	  private String customerStreet;
	  @Column(name = "customer_city",nullable = false)
	  private String customerCity;
	  @Column(name = "customer_country",nullable = false)
	  private String customerCountry;
	
	 @Column(name = "username",nullable = false)
	  private String username;
	  @Column(name = "password",nullable = false)
	  private String password;
	
	  public Customer() {
		// TODO Auto-generated constructor stub
	}

	public Customer(Long customerId, String customerName, @Email String customerEmail,
			@Size(min = 10, max = 10, message = "phone number must be of 10 digit") String customerPhoneNumber,
			String customerHouseNumber, String customerStreet, String customerCity, String customerCountry,
			String username, String password) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerEmail = customerEmail;
		this.customerPhoneNumber = customerPhoneNumber;
		this.customerHouseNumber = customerHouseNumber;
		this.customerStreet = customerStreet;
		this.customerCity = customerCity;
		this.customerCountry = customerCountry;
		this.username = username;
		this.password = password;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerPhoneNumber() {
		return customerPhoneNumber;
	}

	public void setCustomerPhoneNumber(String customerPhoneNumber) {
		this.customerPhoneNumber = customerPhoneNumber;
	}

	public String getCustomerHouseNumber() {
		return customerHouseNumber;
	}

	public void setCustomerHouseNumber(String customerHouseNumber) {
		this.customerHouseNumber = customerHouseNumber;
	}

	public String getCustomerStreet() {
		return customerStreet;
	}

	public void setCustomerStreet(String customerStreet) {
		this.customerStreet = customerStreet;
	}

	public String getCustomerCity() {
		return customerCity;
	}

	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}

	public String getCustomerCountry() {
		return customerCountry;
	}

	public void setCustomerCountry(String customerCountry) {
		this.customerCountry = customerCountry;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerEmail="
				+ customerEmail + ", customerPhoneNumber=" + customerPhoneNumber + ", customerHouseNumber="
				+ customerHouseNumber + ", customerStreet=" + customerStreet + ", customerCity=" + customerCity
				+ ", customerCountry=" + customerCountry + ", username=" + username + ", password=" + password + "]";
	}

	
}
	
	