package com.nineleaps.vegetablestoresystem.Controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.nineleaps.vegetablestoresystem.entity.VegetableItem;
import com.nineleaps.vegetablestoresystem.Exception.ResourceNotFoundException;
import com.nineleaps.vegetablestoresystem.Service.IVegetableItemService;

@CrossOrigin("*")
@RequestMapping("/vegetableitem")
@RestController
public class VegetableItemController {

	@Autowired
	private IVegetableItemService vegetableItemService;
	
	@GetMapping("/listvegetableitem")
	public List<VegetableItem> getAllVegetableItem(){
		return vegetableItemService.getAllVegetableItem();
	}
	
	@PostMapping("/savevegetableitem")
	public VegetableItem saveVegetableItem(@RequestBody VegetableItem vegetableItem) {
		return vegetableItemService.saveVegetableItem(vegetableItem);
	}
	@PutMapping("/updatevegetableitem/{pid}")
	public VegetableItem updateVegetableItem(@RequestBody VegetableItem newvegetableItem,@PathVariable("pid") Long vegetableItemId) throws ResourceNotFoundException{
		VegetableItem vegetableItem = vegetableItemService.getVegetableItemById(vegetableItemId).orElseThrow(() -> new ResourceNotFoundException("vegetableItem not exists with Id" + vegetableItemId));
	  
	  vegetableItem.setVegetableItemName(newvegetableItem.getVegetableItemName());
	  vegetableItem.setVegetableItemPrice(newvegetableItem.getVegetableItemPrice());
	 vegetableItem.setVegetableItemType(newvegetableItem.getVegetableItemType());
	  vegetableItem.setVegetableItemCategory(newvegetableItem.getVegetableItemCategory());
		return vegetableItemService.updateVegetableItem(vegetableItem);
    }
	@GetMapping("/findvegetableitem/{vid}")
	public VegetableItem getVegetableItemById(@PathVariable("vid") Long vegetableItemId){
		return vegetableItemService.getVegetableItemById(vegetableItemId).get();
	}
	@DeleteMapping("/deletevegetableitem/{pid}")
	public void deleteVegetableItemById(@PathVariable("pid") Long vegetableItemId){
		vegetableItemService.deleteVegetableItemById(vegetableItemId);
	}
	
	@GetMapping("/findvegetablename/{vegetablename}")
	public List<VegetableItem> getVegetableItemByVegetableName(@PathVariable("vegetablename") String vegetableItemName) {
		return vegetableItemService.getVegetableItemByVegetableName(vegetableItemName);
	}
	
	

}
