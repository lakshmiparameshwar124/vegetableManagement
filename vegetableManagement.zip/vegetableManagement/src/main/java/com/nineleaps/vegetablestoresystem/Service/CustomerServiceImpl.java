package com.nineleaps.vegetablestoresystem.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nineleaps.vegetablestoresystem.entity.Customer;
import com.nineleaps.vegetablestoresystem.Repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements ICustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Override
	public List<Customer> getAllCustomer() {
		
		return customerRepository.findAll();
	}

	@Override
	public Customer saveCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	@Override
	public Optional<Customer> getCustomerById(Long customerId) {
		
		return customerRepository.findById(customerId);
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepository.save(customer);
	}

	@Override
	public void deleteCustomerById(Long customerId) {
		 
		customerRepository.deleteById(customerId);
		
	}

	@Override
	public Optional<Customer> findByUsernameAndPassword(String username, String password) {
		return customerRepository.findByUsernameAndPassword(username,password);
	}

	@Override
	public Customer insertCustomer(Customer newcustomer) {
		// TODO Auto-generated method stub
		return customerRepository.save(newcustomer);
	}

}



