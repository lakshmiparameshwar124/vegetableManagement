package com.nineleaps.vegetablestoresystem.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;


import com.nineleaps.vegetablestoresystem.entity.VegetableItem;

@Repository
public interface VegetableItemRepository extends JpaRepository<VegetableItem,Long>{

	List<VegetableItem> findByVegetableItemName(String vegetableItemName);

}