package com.nineleaps.vegetablestoresystem.Service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.nineleaps.vegetablestoresystem.entity.Customer;
import com.nineleaps.vegetablestoresystem.entity.VegetableOrder;

public interface IVegetableOrderService {

	
	

	

	public VegetableOrder insertVegetableOrder(VegetableOrder newVegetableOrder);
	

	public List<VegetableOrder> getAllVegetableOrder();

	public VegetableOrder saveVegetableOrder(@Valid VegetableOrder vegetableOrder);

	public Optional<VegetableOrder> getVegetableOrderById(Long orderId);

	public VegetableOrder updateVegetableOrder(VegetableOrder fdorder);

	public void deleteVegetableOrderById(Long orderId);

//	public List<Integer> getAllVegetableOrderPrice(Long customerId);

	
	
	
}