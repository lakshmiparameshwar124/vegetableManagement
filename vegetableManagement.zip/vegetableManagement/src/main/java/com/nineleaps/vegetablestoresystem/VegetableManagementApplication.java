package com.nineleaps.vegetablestoresystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VegetableManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(VegetableManagementApplication.class, args);
	}

}
