package com.nineleaps.vegetablestoresystem.Service;

import java.util.List;
import java.util.Optional;

import com.nineleaps.vegetablestoresystem.entity.Delivery;
import com.nineleaps.vegetablestoresystem.Exception.ResourceNotFoundException;

public interface IDeliveryService  {

	public List<Delivery> getAllDeliveries();
	public Delivery saveDelivery(Delivery delivery);
	public Delivery updateDelivery( Delivery delivery) throws ResourceNotFoundException;
	public Optional<Delivery> getDeliveriesById(Long deliveryId);
	public void deleteDeliveriesById(Long deliveryId);
	public Delivery insertDelivery(Delivery newdelivery);
}
