package com.nineleaps.vegetablestoresystem.Service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nineleaps.vegetablestoresystem.entity.Shop;
import com.nineleaps.vegetablestoresystem.Exception.ResourceNotFoundException;
import com.nineleaps.vegetablestoresystem.Repository.ShopRepository;

@Service
public class ShopServiceImpl implements IShopService {
	
	@Autowired
	private ShopRepository shopRepository;

	@Override
	public List<Shop> getAllShop() {
		return shopRepository.findAll();
	}

	@Override
	public Shop saveShop(Shop shop) {
		return shopRepository.save(shop);
	}

	@Override
	public Optional<Shop> getShopById(Long shopId) {
		
		return shopRepository.findById(shopId);
	}

	@Override
	public void deleteShopById(Long shopId) {
		shopRepository.deleteById(shopId);
	}

	@Override
	public Shop updateShop(Shop shop) throws ResourceNotFoundException {
		return shopRepository.save(shop);
	}

	@Override
	public List<Shop> getShopByShopName(String shopName) {
		// TODO Auto-generated method stub
		return shopRepository.findByShopName(shopName);
	}
}