package com.nineleaps.vegetablestoresystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import  com.nineleaps.vegetablestoresystem.entity.Bill;
import  com.nineleaps.vegetablestoresystem.entity.PlaceOrder;
import  com.nineleaps.vegetablestoresystem.Exception.ResourceNotFoundException;
import  com.nineleaps.vegetablestoresystem.Service.IBillService;
import  com.nineleaps.vegetablestoresystem.Service.IPlaceOrderService;
@CrossOrigin("*")
@RestController
@RequestMapping
public class PlaceOrderController {
	
	@Autowired
	private IPlaceOrderService placeOrderService;
	
	@GetMapping("/listplaceorder")
	public List<PlaceOrder> getAllPlaceOrder(){
		return placeOrderService.getAllPlaceOrder();
	}
	
	@PostMapping("/savePlaceOrder")
	public PlaceOrder savePlaceOrder(@RequestBody PlaceOrder placeOrder) {
		return placeOrderService.saveBill(placeOrder);
	}
	
	@PutMapping("/updateplaceorder/{pOrder_id}")
	public PlaceOrder updatePlaceOrder(@RequestBody PlaceOrder newPlaceOrder,@PathVariable("pOrder_id") Long placeOrderId) throws ResourceNotFoundException {
		PlaceOrder placeOrder =  placeOrderService.getPlaceOrderById(placeOrderId)
				.orElseThrow(() -> new ResourceNotFoundException("place order not exists with id" +placeOrderId));

		placeOrder.setStatus(newPlaceOrder.getStatus());
		placeOrder.setVegetableOrder(newPlaceOrder.getVegetableOrder());
		placeOrder.setShop(newPlaceOrder.getShop());
		return placeOrderService.updatePlaceOrder(placeOrder);
		
	}
	
	@GetMapping("/findplaceorder/{pOrder_id}")
	public PlaceOrder getPlaceOrderById(@PathVariable("pOrder_id") Long placeOrderId){
		return placeOrderService.getPlaceOrderById(placeOrderId).get();
	}
	
	@DeleteMapping("/deleteplaceorder/{pOrder_id}")
	public void deletePlaceOrderById(@PathVariable("pOrder_id") Long placeOrderId){
		placeOrderService.deleteBillById(placeOrderId);
	}

	@PostMapping("/insertPlaceOrder")
	public PlaceOrder insertPlaceOrder(@RequestBody PlaceOrder newplaceOrder) {
	
		return placeOrderService.insertPlaceOrder(newplaceOrder);
	}
	
}
