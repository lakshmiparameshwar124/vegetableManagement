package com.nineleaps.vegetablestoresystem.Service;

import java.util.List;
import java.util.Optional;

import com.nineleaps.vegetablestoresystem.entity.PlaceOrder;

public interface IPlaceOrderService {

	public List<PlaceOrder> getAllPlaceOrder();

	public PlaceOrder saveBill(PlaceOrder placeOrder);

	public Optional<PlaceOrder> getPlaceOrderById(Long placeOrderId);

	public PlaceOrder updatePlaceOrder(PlaceOrder placeOrder);

	public void deleteBillById(Long placeOrderId);

	public PlaceOrder insertPlaceOrder(PlaceOrder newplaceOrder);
	
	
}