package com.nineleaps.vegetablestoresystem.Service;

import java.util.List;
import java.util.Optional;

import com.nineleaps.vegetablestoresystem.entity.Payment;
import com.nineleaps.vegetablestoresystem.Exception.ResourceNotFoundException;

public interface IPaymentService {
	
	public List<Payment> getAllPayment();
	public Payment savePayment(Payment payment);
	public Payment updatePayment(Payment payment)throws ResourceNotFoundException;
	public Optional<Payment> getTransactionById(Long transactionId);
	public void deleteTransactionById(Long transactionId);
}
