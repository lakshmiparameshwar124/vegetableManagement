package com.nineleaps.vegetablestoresystem.Exception;

public class ResourceNotFoundException extends Exception {
	
	public ResourceNotFoundException(String string) {
		super(string);
	}

}
