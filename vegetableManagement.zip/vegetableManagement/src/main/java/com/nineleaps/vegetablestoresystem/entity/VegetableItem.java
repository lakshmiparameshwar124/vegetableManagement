package com.nineleaps.vegetablestoresystem.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Table;

import org.springframework.web.bind.annotation.CrossOrigin;

import javax.persistence.Id;



@Entity
@Table(name= "vegetable_item")
public class VegetableItem {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="vegetable_item_id")
	  private Long vegetableItemId;
	
	
	@Column(name = "vegetable_item_name", nullable = false)
	private String vegetableItemName;
	@Column(name = "vegetable_item_type",nullable = false)
	private String vegetableItemType;
	@Column(name = "vegetable_item_category",nullable = false)
	private String vegetableItemCategory;
	@Column(name = "vegetable_item_price",nullable = false)
	private Integer vegetableItemPrice;

	@Column(name="shop_id")
	 private Long shopId;
	public VegetableItem() {
		// TODO Auto-generated constructor stub
	}
	public VegetableItem(Long vegetableItemId, String vegetableItemName, String vegetableItemType,
			String vegetableItemCategory, Integer vegetableItemPrice, Long shopId) {
		super();
		this.vegetableItemId = vegetableItemId;
		this.vegetableItemName = vegetableItemName;
		this.vegetableItemType = vegetableItemType;
		this.vegetableItemCategory = vegetableItemCategory;
		this.vegetableItemPrice = vegetableItemPrice;
		this.shopId = shopId;
	}
	public Long getVegetableItemId() {
		return vegetableItemId;
	}
	public void setVegetableItemId(Long vegetableItemId) {
		this.vegetableItemId = vegetableItemId;
	}
	public String getVegetableItemName() {
		return vegetableItemName;
	}
	public void setVegetableItemName(String vegetableItemName) {
		this.vegetableItemName = vegetableItemName;
	}
	public String getVegetableItemType() {
		return vegetableItemType;
	}
	public void setVegetableItemType(String vegetableItemType) {
		this.vegetableItemType = vegetableItemType;
	}
	public String getVegetableItemCategory() {
		return vegetableItemCategory;
	}
	public void setVegetableItemCategory(String vegetableItemCategory) {
		this.vegetableItemCategory = vegetableItemCategory;
	}
	public Integer getVegetableItemPrice() {
		return vegetableItemPrice;
	}
	public void setVegetableItemPrice(Integer vegetableItemPrice) {
		this.vegetableItemPrice = vegetableItemPrice;
	}
	public Long getShopId() {
		return shopId;
	}
	public void setShopId(Long shopId) {
		this.shopId = shopId;
	}
	@Override
	public String toString() {
		return "VegetableItem [vegetableItemId=" + vegetableItemId + ", vegetableItemName=" + vegetableItemName
				+ ", vegetableItemType=" + vegetableItemType + ", vegetableItemCategory=" + vegetableItemCategory
				+ ", vegetableItemPrice=" + vegetableItemPrice + ", shopId=" + shopId + "]";
	}
	
	}
	
	
	


