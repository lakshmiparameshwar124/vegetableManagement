package com.nineleaps.vegetablestoresystem.Service;

import java.util.List;
import java.util.Optional;

import com.nineleaps.vegetablestoresystem.Exception.ResourceNotFoundException;
import com.nineleaps.vegetablestoresystem.entity.Shop;


public interface IShopService  {
	
	public List<Shop> getAllShop();
	public Shop saveShop(Shop shop);
	public Shop updateShop(Shop shop)throws ResourceNotFoundException;
	public Optional<Shop> getShopById(Long shopId);
	public void deleteShopById(Long shopId);
	public List<Shop> getShopByShopName(String shopName);

}
