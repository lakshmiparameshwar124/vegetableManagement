package com.nineleaps.vegetablestoresystem.Service;


import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import com.nineleaps.vegetablestoresystem.entity.Customer;
import com.nineleaps.vegetablestoresystem.entity.VegetableOrder;



import com.nineleaps.vegetablestoresystem.entity.OrderDetail;
import com.nineleaps.vegetablestoresystem.Exception.ResourceNotFoundException;

public interface IOrderDetailService {

	public List<OrderDetail> getAllOrders();
	public OrderDetail saveOrder(OrderDetail order);
	public OrderDetail updateOrder( OrderDetail order) throws ResourceNotFoundException;
	public Optional<OrderDetail> getOrderById(Long orderId);
	public void deleteOrderById(Long orderId);
}
