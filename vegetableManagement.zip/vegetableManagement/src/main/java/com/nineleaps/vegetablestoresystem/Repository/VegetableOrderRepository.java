package com.nineleaps.vegetablestoresystem.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nineleaps.vegetablestoresystem.entity.Customer;

import com.nineleaps.vegetablestoresystem.entity.VegetableOrder;

@Repository
public interface VegetableOrderRepository extends JpaRepository<VegetableOrder,Long> {
	
//	@Query("select new com.hexaware.onlinefooddeliveryapp.entity.FoodOrder(food_price) from food_order f where f.filterCol = ?1")
//	List<Integer> getFoodOrderPriceById(Long customerId);
//	
	

}