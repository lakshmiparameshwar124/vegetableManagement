package com.nineleaps.vegetablestoresystem.Service;


import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nineleaps.vegetablestoresystem.entity.Customer;
import com.nineleaps.vegetablestoresystem.entity.VegetableOrder;
import com.nineleaps.vegetablestoresystem.Exception.ResourceNotFoundException;
import com.nineleaps.vegetablestoresystem.Repository.VegetableOrderRepository;

@Service
public class VegetableOrderServiceImpl implements IVegetableOrderService{
	
	@Autowired
	private VegetableOrderRepository vegetableOrderRepository;

	@Override
	public List<VegetableOrder> getAllVegetableOrder() {
		return vegetableOrderRepository.findAll();
	}

	@Override
	public VegetableOrder saveVegetableOrder(@Valid VegetableOrder vegetableOrder) {
		return vegetableOrderRepository.save(vegetableOrder);
	}

	@Override
	public Optional<VegetableOrder> getVegetableOrderById(Long OrderId) {
		return vegetableOrderRepository.findById(OrderId);
	}

	@Override
	public void deleteVegetableOrderById(Long orderId) {
		vegetableOrderRepository.deleteById(orderId);
		
	}

	@Override
	public VegetableOrder updateVegetableOrder(VegetableOrder vegetableorder) {
		return vegetableOrderRepository.save(vegetableorder);
	}

	@Override
	public VegetableOrder insertVegetableOrder(VegetableOrder newVegetableOrder) {
		// TODO Auto-generated method stub
		return vegetableOrderRepository.save(newVegetableOrder);
	}

//	@Override
//	public List<Integer> getAllVegetableOrderPrice(Long customerId) {
//		// TODO Auto-generated method stub
//		return vegetableOrderRepository.getVegetableOrderPriceById(customerId);
//	}
	
	
	
}
