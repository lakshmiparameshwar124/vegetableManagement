package com.nineleaps.vegetablestoresystem.Service;

import java.util.List;
import java.util.Optional;



import com.nineleaps.vegetablestoresystem.entity.Customer;
import com.nineleaps.vegetablestoresystem.entity.VegetableOrder;



import com.nineleaps.vegetablestoresystem.entity.PaymentDetail;
import com.nineleaps.vegetablestoresystem.Exception.ResourceNotFoundException;

public interface IPaymentDetailService {
	
	public List<PaymentDetail> getAllPaymentDetail();
	public PaymentDetail savePaymentDetail(PaymentDetail paymentdetail);
	public PaymentDetail updatePaymentDetail(PaymentDetail paymentdetail)throws ResourceNotFoundException;
	public Optional<PaymentDetail> getPaymentdetailById(Long paymentDetailId);
	public void  deletePaymentdetailById(Long paymentDetailId);
}
