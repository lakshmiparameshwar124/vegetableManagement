package com.nineleaps.leaveManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VegetableManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
